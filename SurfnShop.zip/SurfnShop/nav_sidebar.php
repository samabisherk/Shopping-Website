<div id="sidebar" class = "pull-left">

                <a href="#" class="logo"><img src="images/bag.png" alt=""></a>
                <ul>
                    <li class="">
                        <span><a href="index.php" ><i class="icon-home icon-large"></i> Home</a></span>
                    </li>
                    <li>
                        <span><a href="school.php"><i class=" icon-th-large icon-large"></i> Products</a></span>
                    </li>

                    <li>
                        <span><a href="about.php"><i class="icon-info-sign icon-large"></i> About US</a></span>
                    </li>

					  <li>
                        <span><a href="contact.php"><i class="icon-phone-sign icon-large"></i> Contact US</a></span>
                    </li>
					 <li>
                        <span><a href="faq.php"><i class="icon-comment icon-large"></i> FAQ </a></span>
                    </li>
					  <li>
                        <span><a href="order.php"><i class="icon-shopping-cart icon-large"></i> Order Now</a></span>
                    </li>
                </ul>
                <?php include('sidebar.php'); ?>
                <div class="newsletter">

                </div>
            </div>