<?php
mysql_select_db('db_project',  mysql_connect('localhost','root',''))or die(mysql_error());
?>
