
<ul>
    <li class="">
                        <span><a href="index.php" ><i class="icon-home icon-large"></i> Home</a></span>
                    </li>
                    <li>
                        <span><a href="school.php"><i class=" icon-th-large icon-large"></i> Products</a></span>
                    </li>

                    <li>
                        <span><a href="about.php"><i class="icon-info-sign icon-large"></i> About US</a></span>
                    </li>

                    <li>
                        <span><a href="contact.php"><i class="icon-phone-sign icon-large"></i> Contact US</a></span>
                    </li>
                    <li>
                        <span><a href="order.php"><i class="icon-shopping-cart icon-large"></i> Order Now</a></span>
                    </li>

</ul>
<p>
     <a href="">&copy; Surf N' Shop All Rights Reserved.</a> 
</p>


