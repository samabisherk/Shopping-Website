 <div class="hero-unit-table">
							
		<a href = "user_school.php" name = "" class = "btn btn-success">School</a> 
		<a href = "user_travelling.php" name = "" class = "btn btn-primary">Travelling</a> 			
		<a href = "user_hand.php" name = "" class = "btn btn-info">Hand Bag</a> 
		
						
						
</div>